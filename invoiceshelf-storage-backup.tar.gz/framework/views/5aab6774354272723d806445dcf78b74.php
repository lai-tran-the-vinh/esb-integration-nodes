    <?php $__env->startComponent('mail::layout'); ?>
    
    <?php $__env->slot('header'); ?>
        <?php $__env->startComponent('mail::header', ['url' => '']); ?>
        <?php if($data['company']['logo']): ?>
            <img class="header-logo" src="<?php echo e(asset($data['company']['logo'])); ?>" alt="<?php echo e($data['company']['name']); ?>">
        <?php else: ?>
            <?php echo e($data['company']['name']); ?>

        <?php endif; ?>
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>

    
    <!-- Body here -->

    
    <?php $__env->slot('subcopy'); ?>
        <?php $__env->startComponent('mail::subcopy'); ?>
            <?php echo $data['body']; ?>

            <?php if(!$data['attach']['data']): ?>
                <?php $__env->startComponent('mail::button', ['url' => $data['url']]); ?>
                    <?php echo app('translator')->get('mail_view_invoice'); ?>
                <?php echo $__env->renderComponent(); ?>
            <?php endif; ?>
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>

    
    <?php $__env->slot('footer'); ?>
        <?php $__env->startComponent('mail::footer'); ?>
            Powered by <a class="footer-link" href="https://invoiceshelf.com" target="_blank">InvoiceShelf</a>
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/resources/views/emails/send/invoice.blade.php ENDPATH**/ ?>