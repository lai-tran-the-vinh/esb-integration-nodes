<?php $__env->startComponent('mail::message'); ?>
<?php echo app('translator')->get('mail_viewed_invoice', ['name' => $data['user']['name']]); ?>

<?php $__env->startComponent('mail::button', ['url' => url('/admin/invoices/'.$data['invoice']['id'].'/view')]); ?><?php echo app('translator')->get('mail_view_invoice'); ?>
<?php echo $__env->renderComponent(); ?>

<?php echo app('translator')->get('mail_thanks'); ?>,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/resources/views/emails/viewed/invoice.blade.php ENDPATH**/ ?>