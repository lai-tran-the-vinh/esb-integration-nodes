<?php $__env->startComponent('mail::message'); ?>
<?php echo app('translator')->get('mail_viewed_estimate', ['name' => $data['user']['name']]); ?>

<?php $__env->startComponent('mail::button', ['url' => url('/admin/estimates/'.$data['estimate']['id'].'/view')]); ?><?php echo app('translator')->get('mail_view_estimate'); ?>
<?php echo $__env->renderComponent(); ?>

<?php echo app('translator')->get('mail_thanks'); ?>,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/resources/views/emails/viewed/estimate.blade.php ENDPATH**/ ?>