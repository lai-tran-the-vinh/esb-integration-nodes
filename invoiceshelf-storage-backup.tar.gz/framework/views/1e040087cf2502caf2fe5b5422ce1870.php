<!DOCTYPE html>
<html>

<head>
    <title><?php echo app('translator')->get('pdf_estimate_label'); ?> - <?php echo e($estimate->estimate_number); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <style type="text/css">
        /* -- Base -- */
        body {
            font-family: "DejaVu Sans";
        }

        html {
            margin: 0px;
            padding: 0px;
            margin-top: 50px;
        }

        table {
            border-collapse: collapse;
        }

        hr {
            margin: 0 30px 0 30px;
            color: rgba(0, 0, 0, 0.2);
            border: 0.5px solid #EAF1FB;
        }

        /* -- Header -- */

        .header-container {
            position: absolute;
            width: 100%;
            height: 90px;
            left: 0px;
            top: -50px;
        }

        .header-bottom-divider {
            color: rgba(0, 0, 0, 0.2);
            position: absolute;
            top: 90px;
            left: 0px;
            width: 100%;
        }

        .header-logo {

            margin-top: 20px;
            text-transform: capitalize;
            color: #817AE3;
        }

        .header {
            font-size: 20px;
            color: rgba(0, 0, 0, 0.7);
        }

        .wrapper {
            display: block;
            margin-top: 0px;
            padding-top: 16px;
            padding-bottom: 20px;
        }

        /* -- Company Details -- */

        .company-details-container {
            padding-top: 30px;
        }

        .company-address-container {
            padding-top: 15px;
            float: left;
            padding-left: 30px;
            width: 30%;
            text-transform: capitalize;
            margin-bottom: 2px;
        }

        .company-address-container {
            padding-left: 30px;
            float: left;
            width: 30%;
            text-transform: capitalize;
            margin-bottom: 2px;
        }

        .company-address-container h1 {
            font-size: 15px;
            line-height: 22px;
            letter-spacing: 0.05em;
            margin-bottom: 0px;
            margin-top: 10px;
        }

        .company-address {
            margin-top: 2px;
            text-align: left;
            font-size: 12px;
            line-height: 15px;
            color: #595959;
            width: 280px;
            word-wrap: break-word;
        }

        .estimate-details-container {
            float: right;
            padding: 10px 30px 0 0;
        }

        .attribute-label {
            font-size: 12px;
            line-height: 18px;
            padding-right: 40px;
            text-align: left;
            color: #55547A
        }

        .attribute-value {
            font-size: 12px;
            line-height: 18px;
            text-align: right;
        }

        /* -- Customer Address -- */

        .customer-address-container {
            width: 45%;
            padding: 0px 0 0 0px;
        }

        /* -- Shipping -- */

        .shipping-address-container {
            float: right;
            padding-left: 40px;
            width: 160px;
        }

        .shipping-address-container--left {
            float: left;
            padding-left: 0px;
        }

        .shipping-address-label {
            font-size: 12px;
            line-height: 18px;
            padding: 0px;
            margin-top: 27px;
            margin-bottom: 0px;
        }

        .shipping-address-name {
            max-width: 160px;
            font-size: 15px;
            line-height: 22px;
            padding: 0px;
            margin: 0px;
        }

        .shipping-address {
            font-size: 12px;
            line-height: 15px;
            color: #595959;
            padding-top: 45px;
            padding-left: 40px;
            margin: 0px;
            width: 160px;
            word-wrap: break-word;
        }

        /* -- Billing -- */

        .billing-address-container {
            padding-top: 50px;
            float: left;
            padding-left: 30px;
        }

        .billing-address-label {
            font-size: 12px;
            line-height: 18px;
            padding: 0px;
            margin-top: 27px;
            margin-bottom: 0px;
        }

        .billing-address-name {
            max-width: 160px;
            font-size: 15px;
            line-height: 22px;
            padding: 0px;
            margin: 0px;
        }

        .billing-address {
            font-size: 12px;
            line-height: 15px;
            color: #595959;
            padding: 45px 0px 0px 30px;
            margin: 0px;
            width: 160px;
            word-wrap: break-word;
        }

        /* -- Items Table -- */

        .items-table {
            margin-top: 35px;
            padding: 0px 30px 10px 30px;
            page-break-before: avoid;
            page-break-after: auto;
        }

        .items-table hr {
            height: 0.1px;
        }

        .item-table-heading {
            font-size: 13.5;
            text-align: center;
            color: rgba(0, 0, 0, 0.85);
            padding: 5px;
            padding-bottom: 10px;
        }

        tr.item-table-heading-row th {
            border-bottom: 0.620315px solid #E8E8E8;
            font-size: 12px;
            line-height: 18px;
        }

        .item-table-heading-row {
            margin-bottom: 10px;
        }

        tr.item-row td {
            font-size: 12px;
            line-height: 18px;
        }

        .item-cell {
            font-size: 13;
            color: #040405;
            text-align: center;
            padding: 5px;
            padding-top: 10px;
            border-color: #d9d9d9;
        }

        .item-description {
            color: #595959;
            font-size: 9px;
            line-height: 12px;
        }

        /* -- Total Display Table -- */

        .total-display-container {
            padding: 0 25px;

        }

        .total-display-table {
            border-top: none;
            box-sizing: border-box;
            page-break-inside: avoid;
            page-break-before: auto;
            page-break-after: auto;
            margin-top: 20px;
            float: right;
            width: auto;

        }

        .total-table-attribute-label {
            font-size: 12px;
            color: #55547A;
            text-align: left;
            padding-left: 10px;
        }

        .total-table-attribute-value {
            font-weight: bold;
            text-align: right;
            font-size: 12px;
            color: #040405;
            padding-right: 10px;
            padding-top: 2px;
            padding-bottom: 2px;
        }

        .total-border-left {
            border: 1px solid #E8E8E8 !important;
            border-right: 0px !important;
            padding-top: 0px;
            padding: 8px !important;
        }

        .total-border-right {
            border: 1px solid #E8E8E8 !important;
            border-left: 0px !important;
            padding-top: 0px;
            padding: 8px !important;
        }

        /* -- Notes -- */

        .notes {
            font-size: 12px;
            color: #595959;
            margin-top: 80px;
            margin-left: 30px;
            width: 442px;
            text-align: left;
            page-break-inside: avoid;
        }

        .notes-label {
            font-size: 15px;
            line-height: 22px;
            letter-spacing: 0.05em;
            color: #040405;
            width: 108px;
            white-space: nowrap;
            height: 19.87px;
            padding-bottom: 10px;
        }

        /* -- Helpers -- */

        .text-primary {
            color: #5851DB;
        }

        .text-center {
            text-align: center
        }

        table .text-left {
            text-align: left;
        }

        table .text-right {
            text-align: right;
        }

        .border-0 {
            border: none;
        }

        .py-2 {
            padding-top: 2px;
            padding-bottom: 2px;
        }

        .py-8 {
            padding-top: 8px;
            padding-bottom: 8px;
        }

        .py-3 {
            padding: 3px 0;
        }

        .pr-20 {
            padding-right: 20px;
        }

        .pr-10 {
            padding-right: 10px;
        }

        .pl-20 {
            padding-left: 20px;
        }

        .pl-10 {
            padding-left: 10px;
        }

        .pl-0 {
            padding-left: 0;
        }

    </style>

    <?php if(App::isLocale('th')): ?>
        <?php echo $__env->make('app.pdf.locale.th', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</head>

<body>
    <div class="header-container">
        <table width="100%">
            <tr>
                <td class="text-center">
                    <?php if($logo): ?>
                        <img class="header-logo" style="height:50px" src="<?php echo e(\App\Space\ImageUtils::toBase64Src($logo)); ?>" alt="Company Logo">
                    <?php else: ?>
                        <?php if($estimate->customer->company): ?>
                            <h2 class="header-logo"> <?php echo e($estimate->customer->company->name); ?> </h2>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <hr class="header-bottom-divider" />
    </div>

    <div class="wrapper">
        <div class="company-details-container">
            <div class="company-address-container company-address">
                <?php echo $company_address; ?>

            </div>

            <div class="estimate-details-container">
                <table class="estimate-details-table">
                    <tr>
                        <td class="attribute-label"><?php echo app('translator')->get('pdf_estimate_number'); ?></td>
                        <td class="attribute-value"> &nbsp;<?php echo e($estimate->estimate_number); ?></td>
                    </tr>
                    <tr>
                        <td class="attribute-label"><?php echo app('translator')->get('pdf_estimate_date'); ?></td>
                        <td class="attribute-value"> &nbsp;<?php echo e($estimate->formattedEstimateDate); ?></td>
                    </tr>
                    <tr>
                        <td class="attribute-label"><?php echo app('translator')->get('pdf_estimate_expire_date'); ?></td>
                        <td class="attribute-value"> &nbsp;<?php echo e($estimate->formattedExpiryDate); ?></td>
                    </tr>
                </table>
            </div>
            <div style="clear: both;"></div>
        </div>

        <div class="customer-address-container">
            <?php if($billing_address !== '<br />'): ?>
                <div class="billing-address-container billing-address">
                    <?php if($billing_address): ?>
                        <b><?php echo app('translator')->get('pdf_bill_to'); ?></b> <br>
                        <?php echo $billing_address; ?>

                    <?php endif; ?>
                </div>
            <?php endif; ?>


            <div <?php if($billing_address !== '<br />'): ?> class="shipping-address-container shipping-address" <?php else: ?> class="shipping-address-container--left shipping-address" style="padding-left:30px;" <?php endif; ?>>

                <?php if($shipping_address): ?>
                    <b><?php echo app('translator')->get('pdf_ship_to'); ?> </b> <br>
                    <?php echo $shipping_address; ?>

                <?php endif; ?>
            </div>

            <div style="clear: both;"></div>
        </div>

        <div style="position:relative">
            <?php echo $__env->make('app.pdf.estimate.partials.table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <div class="notes">
            <?php if($notes): ?>
                <div class="notes-label">
                    <?php echo app('translator')->get('pdf_notes'); ?>
                </div>

                <?php echo $notes; ?>

            <?php endif; ?>
        </div>
    </div>
</body>

</html>
<?php /**PATH /var/www/html/resources/views/app/pdf/estimate/estimate1.blade.php ENDPATH**/ ?>