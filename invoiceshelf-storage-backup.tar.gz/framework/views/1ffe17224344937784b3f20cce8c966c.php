<?php $__env->startComponent('mail::message'); ?>
# Test Email from InvoiceShelf

<?php echo e($my_message); ?>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/resources/views/emails/test.blade.php ENDPATH**/ ?>