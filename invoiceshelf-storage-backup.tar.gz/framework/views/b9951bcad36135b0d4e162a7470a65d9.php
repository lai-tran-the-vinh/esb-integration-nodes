<table width="100%" class="items-table" cellspacing="0" border="0">
    <tr class="item-table-heading-row">
        <th width="2%" class="pr-20 text-right item-table-heading">#</th>
        <th width="40%" class="pl-0 text-left item-table-heading"><?php echo app('translator')->get('pdf_items_label'); ?></th>
        <?php $__currentLoopData = $customFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th class="text-right item-table-heading"><?php echo e($field->label); ?></th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <th class="pr-20 text-right item-table-heading"><?php echo app('translator')->get('pdf_quantity_label'); ?></th>
        <th class="pr-20 text-right item-table-heading"><?php echo app('translator')->get('pdf_price_label'); ?></th>
        <?php if($invoice->discount_per_item === 'YES'): ?>
        <th class="pl-10 text-right item-table-heading"><?php echo app('translator')->get('pdf_discount_label'); ?></th>
        <?php endif; ?>
        <?php if($invoice->tax_per_item === 'YES'): ?>
        <th class="pl-10 text-right item-table-heading"><?php echo app('translator')->get('pdf_tax_label'); ?></th>
        <?php endif; ?>
        <th class="text-right item-table-heading"><?php echo app('translator')->get('pdf_amount_label'); ?></th>
    </tr>
    <?php
        $index = 1
    ?>
    <?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="item-row">
            <td
                class="pr-20 text-right item-cell"
                style="vertical-align: top;"
            >
                <?php echo e($index); ?>

            </td>
            <td
                class="pl-0 text-left item-cell"
                style="vertical-align: top;"
            >
                <span><?php echo e($item->name); ?></span><br>
                <span class="item-description"><?php echo nl2br(htmlspecialchars($item->description)); ?></span>
            </td>
            <?php $__currentLoopData = $customFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td class="text-right item-cell" style="vertical-align: top;">
                    <?php echo e($item->getCustomFieldValueBySlug($field->slug)); ?>

                </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <td
                class="pr-20 text-right item-cell"
                style="vertical-align: top;"
            >
                <?php echo e($item->quantity); ?> <?php if($item->unit_name): ?> <?php echo e($item->unit_name); ?> <?php endif; ?>
            </td>
            <td
                class="pr-20 text-right item-cell"
                style="vertical-align: top;"
            >
                <?php echo format_money_pdf($item->price, $invoice->customer->currency); ?>

            </td>

            <?php if($invoice->discount_per_item === 'YES'): ?>
                <td
                    class="pl-10 text-right item-cell"
                    style="vertical-align: top;"
                >
                    <?php if($item->discount_type === 'fixed'): ?>
                            <?php echo format_money_pdf($item->discount_val, $invoice->customer->currency); ?>

                        <?php endif; ?>
                        <?php if($item->discount_type === 'percentage'): ?>
                            <?php echo e($item->discount); ?>%
                        <?php endif; ?>
                </td>
            <?php endif; ?>

            <?php if($invoice->tax_per_item === 'YES'): ?>
                <td
                    class="pl-10 text-right item-cell"
                    style="vertical-align: top;"
                >
                    <?php echo format_money_pdf($item->tax, $invoice->customer->currency); ?>

                </td>
            <?php endif; ?>

            <td
                class="text-right item-cell"
                style="vertical-align: top;"
            >
                <?php echo format_money_pdf($item->total, $invoice->customer->currency); ?>

            </td>
        </tr>
        <?php
            $index += 1
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<hr class="item-cell-table-hr">

<div class="total-display-container">
    <table width="100%" cellspacing="0px" border="0" class="total-display-table <?php if(count($invoice->items) > 12): ?> page-break <?php endif; ?>">
        <tr>
            <td class="border-0 total-table-attribute-label"><?php echo app('translator')->get('pdf_subtotal'); ?></td>
            <td class="py-2 border-0 item-cell total-table-attribute-value">
                <?php echo format_money_pdf($invoice->sub_total, $invoice->customer->currency); ?>

            </td>
        </tr>

        <?php if($invoice->discount > 0): ?>
            <?php if($invoice->discount_per_item === 'NO'): ?>
                <tr>
                    <td class="border-0 total-table-attribute-label">
                        <?php if($invoice->discount_type === 'fixed'): ?>
                            <?php echo app('translator')->get('pdf_discount_label'); ?>
                        <?php endif; ?>
                        <?php if($invoice->discount_type === 'percentage'): ?>
                            <?php echo app('translator')->get('pdf_discount_label'); ?> (<?php echo e($invoice->discount); ?>%)
                        <?php endif; ?>
                    </td>
                    <td class="py-2 border-0 item-cell total-table-attribute-value" >
                        <?php if($invoice->discount_type === 'fixed'): ?>
                            <?php echo format_money_pdf($invoice->discount_val, $invoice->customer->currency); ?>

                        <?php endif; ?>
                        <?php if($invoice->discount_type === 'percentage'): ?>
                            <?php echo format_money_pdf($invoice->discount_val, $invoice->customer->currency); ?>

                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endif; ?>

        <?php if($invoice->tax_included): ?>
        <tr>
            <td class="border-0 total-table-attribute-label">
                <?php echo app('translator')->get('pdf_net_total'); ?>
            </td>
            <td class="py-2 border-0 item-cell total-table-attribute-value">
                <?php echo format_money_pdf($invoice->sub_total - $invoice->discount - $invoice->tax, $invoice->customer->currency); ?>

            </td>
        </tr>
        <?php endif; ?>

        <?php if($invoice->tax_per_item === 'YES'): ?>
            <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border-0 total-table-attribute-label">
                        <?php if($tax->calculation_type === 'fixed'): ?>
                            <?php echo e($tax->name); ?> (<?php echo format_money_pdf($tax->fixed_amount, $invoice->customer->currency); ?>)
                        <?php else: ?>
                            <?php echo e($tax->name.' ('.$tax->percent.'%)'); ?>

                        <?php endif; ?>
                    </td>
                    <td class="py-2 border-0 item-cell total-table-attribute-value">
                        <?php echo format_money_pdf($tax->amount, $invoice->customer->currency); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <?php $__currentLoopData = $invoice->taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border-0 total-table-attribute-label">
                        <?php if($tax->calculation_type === 'fixed'): ?>
                            <?php echo e($tax->name); ?> (<?php echo format_money_pdf($tax->fixed_amount, $invoice->customer->currency); ?>)
                        <?php else: ?>
                            <?php echo e($tax->name.' ('.$tax->percent.'%)'); ?>

                        <?php endif; ?>
                    </td>
                    <td class="py-2 border-0 item-cell total-table-attribute-value">
                        <?php echo format_money_pdf($tax->amount, $invoice->customer->currency); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <tr>
            <td class="py-3"></td>
            <td class="py-3"></td>
        </tr>
        <tr>
            <td class="border-0 total-border-left total-table-attribute-label">
                <?php echo app('translator')->get('pdf_total'); ?>
            </td>
            <td
                class="py-8 border-0 total-border-right item-cell total-table-attribute-value"
                style="color: #5851D8"
            >
                <?php echo format_money_pdf($invoice->total, $invoice->customer->currency); ?>

            </td>
        </tr>

        <?php if($invoice->paid_status === App\Models\Invoice::STATUS_PARTIALLY_PAID || $invoice->paid_status === App\Models\Invoice::STATUS_PAID): ?>
            <tr>
                <td class="border-0 total-border-left total-table-attribute-label">
                    <?php echo app('translator')->get('pdf_amount_paid'); ?>
                </td>
                <td class="py-8 border-0 total-border-right item-cell total-table-attribute-value">
                    <?php echo format_money_pdf($invoice->total - $invoice->due_amount, $invoice->customer->currency); ?>

                </td>
            </tr>
            <tr>
                <td class="border-0 total-border-left total-table-attribute-label">
                    <?php echo app('translator')->get('pdf_amount_due'); ?>
                </td>
                <td class="py-8 border-0 total-border-right item-cell total-table-attribute-value" style="color: #5851D8">
                    <?php echo format_money_pdf($invoice->due_amount, $invoice->customer->currency); ?>

                </td>
            </tr>
        <?php endif; ?>

    </table>
</div>
<?php /**PATH /var/www/html/resources/views/app/pdf/invoice/partials/table.blade.php ENDPATH**/ ?>